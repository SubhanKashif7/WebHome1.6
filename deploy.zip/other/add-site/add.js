function home()
{
    window.history.back();
}

function about()
{
    window.location.href = "https://654f140bef6b6b6db0f3019e--super-cendol-9fc75b.netlify.app/"
}


function github()
{
    window.location.href = "https://github.com/SubhaDev5451";
}